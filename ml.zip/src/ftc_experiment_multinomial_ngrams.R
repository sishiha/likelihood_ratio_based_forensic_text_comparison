### This is a script written by S. Ishihara for calculating LRs with a machine-lerning-based approach. 
### The resultant LRs will be compared with the LRs derived from a deep-learning-based approach.

library(fitdistrplus); library(stylo); library(actuar); library(StatMatch); library(MASS); library(ROCR); library(stats)
library(ROC); library(MGLM); library(usedist); library(dirichlet); library(Compositional); library(MGLM)

source('./tools2/various_tools_for_experiments.R')
source("./tools/kden_mvlr.R")
source("./tools/plot_tippett.R")
source("./tools/calibrate.R")
source("./tools/precision_only_ds_comparison.R")
source("./tools/calc_eer.R")
source("./tools/plot_ece_interface.R")
source("./tools/plot_ece.R")
source("./tools/distance_calculation.R")
source("./tools/authorship_experiment_tools.R")
source("./multinomial_beta_function.R")

prepare.databases<-function(itern, reference.batchnn, test.batchnn, calibration.batchnn, ngramn, ordered) {

# 1, author pairs
# 2, product pairs
# 3-603, feature values for the first text of a pair
# 604-1204, feature values for the second text of a pair
# 1205, 1 (so) or 0 (do)
# 1206, fixed product pairs

    if (ngramn >= 3) {featuren<-500} else {featuren<-600}

    if (ordered == "yes") {
    
        reference.data<-NULL
        for (reference.batchn in reference.batchnn) {
            datafile.name<-paste("../amazon_database_feature_extracted/amazon_iter_", itern,
                                 "_batch_", reference.batchn,
                                 "_ngram_", ngramn,
                                 "_featuren_", featuren, "_ordered.txt", sep="")

            read.data<-read.table(datafile.name, header=FALSE)
            reference.data<-rbind(reference.data, read.data)

        }

        test.data<-NULL
        for (test.batchn in test.batchnn) {
            datafile.name<-paste("../amazon_database_feature_extracted/amazon_iter_", itern,
                                 "_batch_", test.batchn,
                                 "_ngram_", ngramn,
                                 "_featuren_", featuren, "_ordered.txt", sep="")

            read.data<-read.table(datafile.name, header=FALSE)
            test.data<-rbind(test.data, read.data)

        }

        calibration.data<-NULL
        for (calibration.batchn in calibration.batchnn) {
            datafile.name<-paste("../amazon_database_feature_extracted/amazon_iter_", itern,
                                 "_batch_", calibration.batchn,
                                 "_ngram_", ngramn,
                                 "_featuren_", featuren, "_ordered.txt", sep="")

            read.data<-read.table(datafile.name, header=FALSE)
            calibration.data<-rbind(calibration.data, read.data)

        }

    } else if (ordered == "no") {

        reference.data<-NULL
        for (reference.batchn in reference.batchnn) {
            datafile.name<-paste("../amazon_database_feature_extracted/amazon_iter_", itern,
                                 "_batch_", reference.batchn,
                                 "_ngram_", ngramn,
                                 "_featuren_", featuren, ".txt", sep="")

            read.data<-read.table(datafile.name, header=FALSE)
            reference.data<-rbind(reference.data, read.data)

        }

        test.data<-NULL
        for (test.batchn in test.batchnn) {
            datafile.name<-paste("../amazon_database_feature_extracted/amazon_iter_", itern,
                                 "_batch_", test.batchn,
                                 "_ngram_", ngramn,
                                 "_featuren_", featuren, ".txt", sep="")

            read.data<-read.table(datafile.name, header=FALSE)
            test.data<-rbind(test.data, read.data)

        }

        calibration.data<-NULL
        for (calibration.batchn in calibration.batchnn) {
            datafile.name<-paste("../amazon_database_feature_extracted/amazon_iter_", itern,
                                 "_batch_", calibration.batchn,
                                 "_ngram_", ngramn,
                                 "_featuren_", featuren, ".txt", sep="")

            read.data<-read.table(datafile.name, header=FALSE)
            calibration.data<-rbind(calibration.data, read.data)

        }


    } else {print("The variable of 'ordered' needs to be either 'yes' or 'no'.")}

    return(list(reference.data, test.data, calibration.data))

}


# itern, reference.batchnn, test.batchnn, calibration.batchnn, ngramn, feanumber

authorship.experiment.ml<-function(itern,
                                    reference.batchnn,
                                    test.batchnn,
                                    calibration.batchnn,
                                    ngramn,
                                   feanumber,
                                   ordered) {        # refer to the below

    out<-prepare.databases(itern, reference.batchnn, test.batchnn, calibration.batchnn, ngramn, ordered)
    
    collap.reference.batchnn<-paste(reference.batchnn,collapse="")
    collap.test.batchnn<-paste(test.batchnn,collapse="")
    collap.calibration.batchnn<-paste(calibration.batchnn,collapse="")

    reference.data<-out[[1]]; test.data<-out[[2]]; calibration.data<-out[[3]]

    test.author.pairs<-test.data[,1]
    calibration.author.pairs<-calibration.data[,1]

    test.product.pairs<-test.data[,2]
    calibration.product.pairs<-calibration.data[,2]

    if (ngramn >= 3) {
        test.fixed.product.pairs<-test.data[,1006]
        calibration.fixed.product.pairs<-calibration.data[,1006]

        test.so.do<-test.data[,1005]
        calibration.so.do<-calibration.data[,1005]

    } else {
        test.fixed.product.pairs<-test.data[,1206]
        calibration.fixed.product.pairs<-calibration.data[,1206]

        test.so.do<-test.data[,1205]
        calibration.so.do<-calibration.data[,1205]

    }

    number.of.features<-feanumber
    print(paste("Iteration number:", itern, sep=" "))
    print(paste("Ngram: ", ngramn, "gram", sep=""))
    print(paste("Ref set:", collap.reference.batchnn, sep=" "))
    print(paste("Test set:", collap.test.batchnn, sep=" "))
    print(paste("Calib set:", collap.calibration.batchnn, sep=" "))
    print(paste("Feature number:", feanumber, sep=" "))
    print(paste("Feature ordered:", ordered, sep=" "))

    suffix.write.file.root.name<-paste("iter_",
                                       itern,
                                       "_",
                                       ngramn, "gram",
                                       "_ref_",
                                       collap.reference.batchnn,
                                       "_test_",
                                       collap.test.batchnn,
                                       "_calib_",
                                       collap.calibration.batchnn,
                                       "_fnumber_",
                                       number.of.features,
                                       "_ordered_",
                                       ordered,
                                       sep="")

    # sa.write.file.root.name<-paste("sa_comparisons_",suffix.write.file.root.name,".txt",sep="")
    # da.write.file.root.name<-paste("da_comparisons_",suffix.write.file.root.name,".txt",sep="")

    if (ngramn >= 3) {
        n.col<-number.of.features
        selected.features.reference.first<-reference.data[,3:503]
        selected.features.reference.second<-reference.data[,504:1004]
        selected.features.reference<-rbind(as.matrix(selected.features.reference.first),
                                           as.matrix(selected.features.reference.second))

        selected.features.test.first<-test.data[,3:503]
        selected.features.test.second<-test.data[,504:1004]

        selected.features.calibration.first<-calibration.data[,3:503]
        selected.features.calibration.second<-calibration.data[,504:1004]

    } else {
        n.col<-number.of.features
        selected.features.reference.first<-reference.data[,3:603]
        selected.features.reference.second<-reference.data[,604:1204]
        selected.features.reference<-rbind(as.matrix(selected.features.reference.first),
                                           as.matrix(selected.features.reference.second))

        selected.features.test.first<-test.data[,3:603]
        selected.features.test.second<-test.data[,604:1204]

        selected.features.calibration.first<-calibration.data[,3:603]
        selected.features.calibration.second<-calibration.data[,604:1204]

}

    # concatinate the selected feature values and the sum of the remainder features after smoothing (adding 1)
    # x<-data.manupulation.smoothing(selected.feature.values,n.col)
    x.selected.features.reference<-data.manupulation.smoothing.deep(selected.features.reference, n.col)

    x.selected.features.test.first<-data.manupulation.smoothing.deep(selected.features.test.first, n.col)
    x.selected.features.test.second<-data.manupulation.smoothing.deep(selected.features.test.second, n.col)
    x.selected.features.test<-cbind(x.selected.features.test.first, x.selected.features.test.second)

    x.selected.features.calibration.first<-data.manupulation.smoothing.deep(selected.features.calibration.first, n.col)
    x.selected.features.calibration.second<-data.manupulation.smoothing.deep(selected.features.calibration.second, n.col)
    x.selected.features.calibration<-cbind(x.selected.features.calibration.first, x.selected.features.calibration.second)

    diri.paras<-diri.nr(as.matrix(x.selected.features.reference/rowSums(x.selected.features.reference)))
    alpha<-diri.paras$param

    ### test scores calculations
    ### test scores calculations

    test.scores<-apply(x.selected.features.test,
                       1,
                       modified.log10LR.mnom.two.level,
                       alpha)

    test.results.df<-data.frame(scores=test.scores,
                                authorpairs=test.author.pairs,
                                productpairs=test.product.pairs,
                                fixedproductpairs=test.fixed.product.pairs,
                                sodo=test.so.do)

    test.score.out.file.name<-paste("../ml_experiment_outcome/score_dump/",
                                    "test_scores_", 
                                    suffix.write.file.root.name, ".txt", sep="")

    write.table(test.results.df,
                test.score.out.file.name,
                sep=" ",
                row.names=FALSE, quote=FALSE)

    ### calibration scores calculations
    ### calibration scores calculations

    calibration.scores<-apply(x.selected.features.calibration,
                              1,
                              modified.log10LR.mnom.two.level,
                              alpha)

    calibration.results.df<-data.frame(scores=calibration.scores,
                                       authorpairs=calibration.author.pairs,
                                       productpairs=calibration.product.pairs,
                                       fixedproductpairs=calibration.fixed.product.pairs,
                                       sodo=calibration.so.do)

    calibration.score.out.file.name<-paste("../ml_experiment_outcome/score_dump/",
                                           "calibration_scores_", 
                                           suffix.write.file.root.name, ".txt", sep="")

    write.table(calibration.results.df,
                calibration.score.out.file.name,
                sep=" ",
                row.names=FALSE, quote=FALSE)

    # test.readin<-read.table(test.score.out.file.name, header=TRUE)

    # sa.scores<-test.readin[which(test.readin[,5] == 1),1]
    # da.scores<-test.readin[which(test.readin[,5] == 0),1]

    #####################################
    ### Cllr calculation
    ### Cllr calculation

    test.lr.out.file.name<-paste("../ml_experiment_outcome/lr_dump/",
                                 "test_lrs_", 
                                 suffix.write.file.root.name, ".txt", sep="")

    cllr.out.file.name<-paste("../ml_experiment_outcome/metrics/",
                              "cllr_", 
                              suffix.write.file.root.name, ".txt", sep="")
        
    cllr.min.cal.combined<-calibrate.roc.eer.ver2(test.score.out.file.name,
                                                  calibration.score.out.file.name,
                                                  test.lr.out.file.name,
                                                  cllr.out.file.name)

    print(data.frame(cllr.min.cal.combined))
    
    #####################################
    ### Tippett plot
    ### Tippett plot 

    score.lr.tippett.file.name<-paste("../ml_experiment_outcome/figures/tippett_uncalib_calib_",
                                      suffix.write.file.root.name,".jpeg",sep="")

    plot.uncalib.calib.tippett.plot.ver2(test.score.out.file.name,
                                         test.lr.out.file.name,
                                         score.lr.tippett.file.name)
        
    rm(list=ls(all=TRUE))
    gc(reset = TRUE)
    gc(reset = TRUE)
}

######### main script

# itern<-2
# ngramn<-1
# feanumber<-100   # N >= 3: 500 # N <= 2: 600

# reference.batchnn<-c(5,1,2)
# test.batchnn<-c(3)
# calibration.batchnn<-c(4)
# ordered<-"yes"

# authorship.experiment.ml(itern,
#                         reference.batchnn,
#                         test.batchnn,
#                         calibration.batchnn,
#                         ngramn,
#                         feanumber,
#                         ordered)

