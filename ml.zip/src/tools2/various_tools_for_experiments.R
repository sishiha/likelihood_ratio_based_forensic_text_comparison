### Draw a tippett plot
# file.sources1 = list.files("./focal_r/cllr",full.names=TRUE, pattern="*.[Rr]$")
# file.sources2 = list.files("./focal_r/fusion",full.names=TRUE, pattern="*.[Rr]$")
# file.sources3 = list.files("./focal_r/utils",full.names=TRUE, pattern="*.[Rr]$")
# sapply(file.sources1,source,.GlobalEnv)
# sapply(file.sources2,source,.GlobalEnv)
# sapply(file.sources3,source,.GlobalEnv)
#################### plot only scores

plot.tippett<-function(so.data,do.data) {
    par(mar=c(4,4,1,1))
    plot(sort(so.data), seq(from=0, to =1, 
                       length = length(so.data)), xlims<-c(-15,5),
     xlab=expression(paste(log[10], "(LR)")), ylab = "Cumulative Proportion",
     type = "l", col = "black", lwd = 3, lty = "solid")
  
    points(sort(do.data), seq(from=1, to =0, length = length(do.data)),
           type = "l", col = "gray", lwd = 3, lty = "solid")

                                        # title(main = "Intrinsic 2-level kden log10MV Scores")

    grid(nx = NULL, col = "gray", lty = "dotted", lwd = 1)
    abline(v = 0)
    abline(h = 0.1 * 1:9, col="gray", lty = "dotted", lwd = 1)

}

calibration.new<-function(so.data,do.data){

    logetss<-rbind(log(10^so.data))
    logetds<-rbind(log(10^do.data))

    w <- train.llr.fusion(logetss,logetds)
    print("Calculated the calibration weight")
    targetf <- lin.fusion(w, logetss)
    nontargetf <- lin.fusion(w, logetds)

    log10targetf <- as.vector(log10(exp(targetf)))
    log10nontargetf <- as.vector(log10(exp(nontargetf)))
    print("Completed calibration")

    # non.calib.cllr.value <- cllr(logetss,logetds)
    # non.calib.cllr.min.value <- cllr.min(logetss,logetds)
    # non.calib.cllr.cal.value <- cllr.cal(logetss,logetds)
    # non.calib.cllr.min.cal.values <- c(non.calib.cllr.value,
    #                                   non.calib.cllr.min.value,
    #                                   non.calib.cllr.cal.value)
    #print(non.calib.cllr.min.cal.values)

    all.non.calib.cllr.min.cal.value <- cllr.min.cal(logetss,logetds)
    print(all.non.calib.cllr.min.cal.value)

    # calib.cllr.value <- cllr(targetf,nontargetf)
    # calib.cllr.min.value <- cllr.min(targetf,nontargetf)
    # calib.cllr.cal.value <- cllr.cal(targetf,nontargetf)
    # calib.cllr.min.cal.values <- c(calib.cllr.value,
    #                               calib.cllr.min.value,
    #                               calib.cllr.cal.value)

    # print(calib.cllr.min.cal.values)

    all.calib.cllr.min.cal.value <- cllr.min.cal(targetf,nontargetf)
    print(all.calib.cllr.min.cal.value)
    # title.calib.cllr.min.cal.values<-(rbind(c("cllr","cllrmin","cllrcal"),calib.cllr.min.cal.values))
    # write.table(title.calib.cllr.min.cal.values,file=filename, sep=" ", quote=FALSE, row.names = FALSE, col.names = FALSE)

}

plot.uncalib.tippett.plot<-function(uncalib.ssfile,
                                    uncalib.dsfile,
                                    tippett.plot.path
                                    ) {

    uncalib.ss.data<-read.table(uncalib.ssfile, header=FALSE)
    uncalib.ds.data<-read.table(uncalib.dsfile, header=FALSE)

    uncalib.ss.lrs<-uncalib.ss.data[,2]
    uncalib.ds.lrs<-c(uncalib.ds.data[,3], uncalib.ds.data[,4])

    writefile<-tippett.plot.path

    jpeg(writefile, width=480, quality = 100, height=480, pointsize=16)
    par(mar=c(4,4,1,1))
    plot(sort(uncalib.ss.lrs), seq(from=0, to =1, 
                                   length = length(uncalib.ss.lrs)), xlims<-c(-15,5),
         xlab=expression(paste(log[10], "(score)")), ylab = "Cumulative Proportion",
         type = "l", col = "black", lwd = 3, lty = "dotted")
  
    points(sort(uncalib.ds.lrs), seq(from=1, to =0, length = length(uncalib.ds.lrs)),
           type = "l", col = "gray", lwd = 3, lty = "dotted")

    # title(main = "Intrinsic 2-level kden log10MV Scores")

    grid(nx = NULL, col = "gray", lty = "dotted", lwd = 1)
    abline(v = 0)
    abline(h = 0.1 * 1:9, col="gray", lty = "dotted", lwd = 1)

    dev.off()

    ############## remove all assignments
    rm(list=ls(all=TRUE))
  
}

