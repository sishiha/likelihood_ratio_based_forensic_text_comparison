# input of cllr.cal: loge
cllr.min.cal <- function (tar.scores, nontar.scores) {
  # input of cllr.cal: loge
    cllr <- cllr(tar.scores, nontar.scores)
  # input of cllr.min: loge
    cllr.min <- cllr.min(tar.scores, nontar.scores)
    cllr.cal <- cllr - cllr.min
    # cllr.all<-c(cllr)
    cllr.all<-c(cllr,cllr.min,cllr.cal)
    
  return(cllr.all)
  
}

