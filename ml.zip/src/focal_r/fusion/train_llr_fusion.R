# This is an R version of train_llr_fusion.
#  Train Linear fusion with prior-weighted Logistic Regression objective.
#  The fusion output is encouraged by this objective to be a well-calibrated log-likelihood-ratio.
#  I.E., this is simultaneous fusion and calibration.
#
#  Usage:
#    
#    
#   
#  Input parameters:
#    targets:     a [d,nt] matrix of nt target scores for each of d systems to be fused. 
#    non_targets: a [d,nn] matrix of nn non-target scores for each of the d systems.
#    prior:       (optional, default = 0.5), a scalar parameter between 0 and 1.
#                 This weights the objective function, by replacing the effect 
#                 that the proportion nt/(nn+nt) has on the objective.
#                 For general use, omit this parameter (i.e. prior = 0.5).
#                 For NIST SRE, use: prior = effective_prior(0.01,10,1);
#
#  Output parameters:
#    w: a vector of d+1 fusion coefficients.
#         The first d coefficients are the weights for the d input systems.
#         The last coefficient is an offset (see below).
#
#  Fusion of new scores:
#    see: LIN_FUSION.m
# 
#

train.llr.fusion<-function(target.log10lrs, nontarget.log10lrs, prior) {
  # tar.logelrs<-log(10^tar.log10lrs) # conversion to log(e) LRs
  # nontar.logelrs<-log(10^nontar.log10lrs) # conversion to log(e) LRs

  prior <- 0.5
  # nt <- length(target.log10lrs)
  # nn <- length(nontarget.log10lrs)
  nt <- ncol(target.log10lrs)
  nn <- ncol(nontarget.log10lrs)

  prop <- nt/(nn+nt)
  
  weights <- c((prior/prop)*rep(1,nt), ((1-prior)/(1-prop))*rep(1,nn))

  x1 <- rbind(target.log10lrs, rep(1,nt))
  x2 <- rbind(-(nontarget.log10lrs), -(rep(1,nn)))
  x <- cbind(x1,x2)
  w <- matrix(0,nrow(x),1)

  offset = logit(prior)*c(rep(1,nt), -(rep(1,nn)))

  d <- dim(x)[1]
  n <- dim(x)[2]

  old.g <- matrix(rep(0), nrow(x), 1)

  for (i in 1:1000) {
    old.w <- w
    s1 = 1./(1+exp(t(w)%*%x+offset))
    g = x%*%t(s1*weights)
    
    if (i == 1) {
      u <- g
     } else {
       u = cg.dir(u, g, old_g)
     }

    ug <- t(u)%*%g
    ux <- t(u)%*%x
    a <- weights*s1*(1-s1)
    uhu <- (ux^2)%*%t(a)
    ug.uhu <- as.vector(ug/uhu)

   ### originally the following should be a matrix product
   ### w <- w + ug.uhu%*%u
    w <- w + ug.uhu*u

    old_g = g
    if (max(abs(w - old.w)) < 1e-5) {

      break

    }

  }
  if (i == 1000) {
    puts('not enough iters')
    
  }
  return(matrix(w))
}
