calc.plot.ece<-function(ss.file,ds.file,ece.plot.file) {
    library(comparison)
  
    ss.read.data<-read.table(ss.file,header=FALSE)
    ds.read.data<-read.table(ds.file,header=FALSE)

    ### conversion from log10LRs to logeLR
    ss.lrs<-10^ss.read.data[,1]
    ds.lrs<-10^ds.read.data[,1]

    ### a function in comparison library
    ece.values <- calc.ece(ss.lrs, ds.lrs, prior=seq(from=0.001,to=0.999,length=180))

    # a function created by David Lucy
    plot.ece(ece.values, ece.plot.file) 

    rm(list=ls(all=TRUE))
  
}
