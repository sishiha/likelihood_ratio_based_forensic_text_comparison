#############################################################################################
# functions to conduct emprical cross entropy calculations
# these functions are a reworking of Danial Ramos' ECE functions for Matlab
# (c) David Lucy 22 June 2010
# does the plotting
# a minor modification was made by Shunichi Ishihara
#############################################################################################
plot.ece<-function(x, writefile) {
  
  # get rid of these eventually
  # postscript(file=ps.file.name, horizontal=FALSE, paper="special", width=7, height=7, pointsize=14)
  # par(oma=c(0,0,0,0))
  # par(mar=c(4,4,1,1))
  # par(las=1)

  # eventually make these user selectable
  null.colour <- "grey"
  ece.colour <- "black"
  calibrated.colour <- "black"
  colours.vec <- c(null.colour, ece.colour, calibrated.colour)

  legend.text <- c("LR=1 always", "LR values", "After PAV")

  # dereference all the bits from the ece object
  prior <- slot(x, "prior")
  ece.null <- slot(x, "ece.null")
  ece <- slot(x, "ece")
  ece.cal <- slot(x, "ece.cal")
	
  x.ordinates <- log10(prior / (1 - prior))
  legend.x.position <- x.ordinates[1] + 3.55
	
  # x.axis.text <- expression(paste(log[10], Odds(theta)))
  x.axis.text <- expression(paste("Prior ", log[10], "(odds)"))        
  y.axis.text <- "Empirical cross-entropy"
    
  max.y <- max(c(ece.null, ece, ece.cal)) + 0.07
  
  jpeg(writefile, width=480, quality = 100, height=480, pointsize=16)
  par(mar=c(4,4,1,1))

  plot(x.ordinates, ece.null, col=null.colour, xlim=c(-2.5,2.5), ylim=c(0,max.y), type="l", xlab=x.axis.text, ylab=y.axis.text,
       lty="solid", lwd=2.5)
  points(x.ordinates, ece, col=ece.colour, type="l", lwd=2.5)
  points(x.ordinates, ece.cal, col=calibrated.colour, type="l", lty="dashed", lwd=2.5)

  # mtext(text=x.axis.text, side=1, line=2.5, cex=1.2)
  # mtext(text=y.axis.text, side=2, line=2.8, cex=1.2, las=0)

  legend(legend.x.position, max.y, legend=legend.text, col=colours.vec, lty=c("solid","solid","dashed"), lwd=2.5, bty="n")

  abline(h=0.1*1:20, lty="dotted", lwd=0.5)
  abline(v=0.5*-6:6, lty="dotted", lwd=0.5)

  abline(h=0, lty=3)
  abline(v=0, lty="dotted", lwd=2)

  dev.off()

}

