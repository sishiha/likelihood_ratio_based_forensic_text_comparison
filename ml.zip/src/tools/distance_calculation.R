calculate.distance<-function(data.x,
                             distance.measure,
                             var.x=NULL) {

    if (distance.measure == "argamon") {
        y<-as.matrix(dist.argamon(as.matrix(data.x), scale=FALSE))
        print(paste("Distance measure:", distance.measure, sep=" "))
    }
    if (distance.measure == "cosine") {
        y<-as.matrix(dist.cosine(as.matrix(data.x)))
        print(paste("Distance measure:", distance.measure, sep=" "))
    }
    if (distance.measure == "delta") {
        y<-as.matrix(dist.delta(as.matrix(data.x), scale=FALSE))
        print(paste("Distance measure:", distance.measure, sep=" "))
    }
    if (distance.measure == "mahalanobis") {
        y<-as.matrix(mahalanobis.dist(as.matrix(data.x), vc=var.x))
        print(paste("Distance measure:", distance.measure, sep=" "))
    }

    print("Finished calculating the distances")
    return(y)
}

calculate.within.author.cov.matrix<-function(x.data,
                             var.type,
                             var.scale.factor=1) {

    x.data.row.number<-nrow(x.data)
    if (var.type == "within") {
        first.session<-seq(1,x.data.row.number,2)

        second.session<-seq(2,by=2,len=x.data.row.number/2)
        session.one.session.two.matrix<-cbind(first.session,second.session)
            # all.vars<-NULL
            # apply(session.one.session.two.matrix, 1, function(one.two) x.data[one.two[1,],])
        list.of.vars<-apply(session.one.session.two.matrix, 1,
                            function(one.two) list(var(as.matrix(x.data[one.two,]))))

        for (i in 1:length(list.of.vars)) {
            if (i == 1) {
                all.vars<-as.matrix(list.of.vars[[i]][1][[1]])
            }
            else {all.vars<-all.vars + as.matrix(list.of.vars[[i]][1][[1]])
            }
        
        }
        var.x<-(all.vars / (length(list.of.vars))) * (var.scale.factor^-1)
        # print(all.vars)
        # rm(list.of.vars)
        # rm(all.vars)
        # gc(reset = TRUE)
        # gc(reset = TRUE)

    }

    if (var.type == "all") {
        var.x<-var(x.data)*(var.scale.factor^-1)
        
    }
    print("Finished calculating the co-variance")
    # print(x.data.row.number)
    return(var.x)
    
}


