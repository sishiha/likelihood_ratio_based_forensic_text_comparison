source('./ftc_experiment_multinomial_ngrams.R')

##############################################
# wordngram: 600 features
# charngram: 1000 features
##############################################

# c(5,10*1:6, 20*4:25)) # upto 500
# c(5,10*1:6, 20*4:30)) # upto 600

itern<-2
ngramn<-3
ordered<-"yes"
feanumbers<-c(5,10*1:6, 20*4:25)   # N >= 3: 500 # N <= 2: 600
feanumbers<-c(5)   # N >= 3: 500 # N <= 2: 600

reference.batchnn<-list(c(1,2,3), c(2,3,4), c(3,4,5), c(4,5,1), c(5,1,2))
# reference.batchnn<-list(c(1,2,3))
test.batchnn<-c(4,5,1,2,3)
# test.batchnn<-c(4)
calibration.batchnn<-c(5,1,2,3,4)
# calibration.batchnn<-c(5)

for (k in 1:length(reference.batchnn)) {
    for (feanumber in feanumbers) {

        reference.batchn<-reference.batchnn[[k]]
        test.batchn<-test.batchnn[k]
        calibration.batchn<-calibration.batchnn[k]
        # print(reference.batchn)
        # print(test.batchn)
        # print(calibration.batchn)

        authorship.experiment.ml(itern,
                                 reference.batchn,
                                 test.batchn,
                                 calibration.batchn,
                                 ngramn,
                                 feanumber,
                                 ordered)
    }
}




